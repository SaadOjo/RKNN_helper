class TextOverlay:
    def __init__(self):
        print('print from __init__ fps')
